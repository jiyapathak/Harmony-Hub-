# Visual Flow & Architecture Guide

## System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        FRONTEND (Browser)                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐       │
│  │    Shop      │    │    Cart      │    │   Checkout   │       │
│  │   (shop.js)  │───▶│ (cart.js)    │───▶│(checkout.js) │       │
│  └──────────────┘    └──────────────┘    └──────────────┘       │
│         │                    │                    │              │
│         │                    │                    ▼              │
│         │                    │            ┌─────────────────┐   │
│         │                    │            │ Delivery Form   │   │
│         │                    │            │ Payment Method  │   │
│         │                    │            │ Order Summary   │   │
│         │                    │            └─────────────────┘   │
│         │                    │                    │              │
│         │                    │                    ▼              │
│         │                    │            ┌─────────────────┐   │
│         │                    │            │  Place Order    │   │
│         │                    │            │  (POST API)     │   │
│         │                    │            └─────────────────┘   │
│         │                    │                    │              │
│         │                    │                    ▼              │
│         │                    │            ┌─────────────────┐   │
│         │                    │            │    Profile      │   │
│         │                    │            │ (profile.js)    │   │
│         │                    │            └─────────────────┘   │
│         │                    │                    │              │
│         ▼                    ▼                    ▼              │
│    ┌─────────────────────────────────────────────────┐          │
│    │         localStorage (Cart Data)                │          │
│    └─────────────────────────────────────────────────┘          │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
                            │
                ┌───────────┼───────────┐
                │           │           │
                ▼           ▼           ▼
        ┌──────────────────────────────────────┐
        │         API LAYER (Flask)            │
        ├──────────────────────────────────────┤
        │                                      │
        │  POST   /api/orders                  │
        │  GET    /api/user/orders             │
        │  GET    /api/orders/<id>             │
        │  GET    /api/admin/sales-data        │
        │  GET    /api/auth/status             │
        │                                      │
        └──────────────────────────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        │                   │                   │
        ▼                   ▼                   ▼
    ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
    │  Orders DB   │  │ OrderItems   │  │ SalesTracking│
    │              │  │              │  │              │
    │ - id         │  │ - id         │  │ - id         │
    │ - user_id    │  │ - order_id   │  │ - product_id │
    │ - total      │  │ - product_id │  │ - qty_sold   │
    │ - payment    │  │ - quantity   │  │ - revenue    │
    │ - address    │  │ - price      │  │ - updated_at │
    │ - status     │  │ - order_id   │  └──────────────┘
    │ - created_at │  └──────────────┘
    └──────────────┘
```

---

## User Journey Flow

### 👤 Customer Flow

```
START
  │
  ▼
┌─────────────────────┐
│  Browse Products    │
│  (Shop Page)        │
└─────────────────────┘
  │
  ├─── Add to Cart ──┐
  │                  │
  ▼                  │
┌──────────────────┐ │
│  View Cart       │ │
│  (Cart Page)     │ │
└──────────────────┘ │
  │                  │
  ├─── Continue ─────┤
  │  Shopping        │
  │                  │
  └──────────────────┘
  │
  ▼
┌──────────────────────────┐
│ Proceed to Checkout      │
│ Check Login Status       │
└──────────────────────────┘
  │
  ├─── Not Logged In ──┐
  │                    │
  ▼                    │
┌─────────────────┐   │
│  Login Page     │   │
└─────────────────┘   │
  │                   │
  └───────────┬───────┘
              │
              ▼
┌──────────────────────────────┐
│  CHECKOUT PAGE               │
│  ────────────────────────    │
│  Delivery Information         │
│  - Full Name                  │
│  - Phone Number               │
│  - Email                      │
│  - Address                    │
│  - City                       │
│  - ZIP Code                   │
└──────────────────────────────┘
  │
  ▼
┌──────────────────────────────┐
│  SELECT PAYMENT METHOD       │
│  ────────────────────────    │
│  ◉ Cash on Delivery           │
│  ○ Credit/Debit Card          │
│  ○ Digital Wallet             │
└──────────────────────────────┘
  │
  ▼
┌──────────────────────────────┐
│  REVIEW ORDER SUMMARY        │
│  ────────────────────────    │
│  Items in Cart               │
│  Subtotal                    │
│  Shipping                    │
│  Tax                         │
│  TOTAL                       │
└──────────────────────────────┘
  │
  ▼
┌──────────────────────────────┐
│  PLACE ORDER                 │
│  [Place Order Button]        │
└──────────────────────────────┘
  │
  ▼
┌──────────────────────────────┐
│  API: POST /api/orders       │
│  ────────────────────────    │
│  Creates Order Record        │
│  Creates Order Items         │
│  Updates Stock               │
│  Updates Sales Tracking      │
│  Returns Order ID            │
└──────────────────────────────┘
  │
  ▼
┌──────────────────────────────┐
│  ✅ ORDER CONFIRMED          │
│  Order #12345                │
│  Clear Cart                  │
│  Redirect to Profile         │
└──────────────────────────────┘
  │
  ▼
┌──────────────────────────────┐
│  MY ORDERS (Profile Page)    │
│  ────────────────────────    │
│  Order #12345                │
│  Status: Pending             │
│  Date: Dec 29, 2024 2:30 PM  │
│  Total: $1,299.99            │
│  [View Details]              │
└──────────────────────────────┘
  │
  ▼
┌──────────────────────────────┐
│  ORDER DETAILS MODAL         │
│  ────────────────────────    │
│  Order Info                  │
│  Items Ordered               │
│  Pricing Breakdown           │
│  Delivery Address            │
│  Payment Method              │
└──────────────────────────────┘
  │
  ▼
END (Order Complete)
```

---

## Admin Dashboard Flow

```
ADMIN LOGIN
  │
  ▼
┌──────────────────────┐
│  Admin Dashboard     │
└──────────────────────┘
  │
  ├──▶ [View Sales Data]
  │    │
  │    ▼
  │    GET /api/admin/sales-data
  │    │
  │    ├─ Product Name
  │    ├─ Category
  │    ├─ Quantity Sold
  │    ├─ Total Revenue
  │    └─ Last Updated
  │
  └──▶ [View Inventory]
       │
       ▼
       GET /api/admin/inventory
       │
       ├─ Product ID
       ├─ Product Name
       ├─ Category
       ├─ Current Stock
       ├─ Price
       ├─ Units Sold
       └─ Revenue Generated
```

---

## Database Transaction Flow

### When Order is Placed:

```
1. User submits checkout form
   │
   ├─ Data Validation ──▶ ❌ (Error) ──▶ Show Error Message
   │
   ▼ ✅ (Valid)

2. POST /api/orders received
   │
   ▼

3. BEGIN DATABASE TRANSACTION
   │
   ├─ INSERT INTO orders (user_id, total, payment_method, address, status)
   │  Returns: order_id = 42
   │
   ├─ FOR EACH item in cart:
   │  │
   │  ├─ INSERT INTO order_items (order_id, product_id, quantity, price)
   │  │
   │  ├─ UPDATE products SET stock = stock - quantity WHERE id = product_id
   │  │
   │  └─ INSERT/UPDATE sales_tracking:
   │     quantity_sold += quantity
   │     total_revenue += (price × quantity)
   │
   ▼

4. COMMIT TRANSACTION ✅
   │
   ▼

5. Return Success Response
   {
     "message": "Order created successfully",
     "order_id": 42,
     "status": "pending"
   }
   │
   ▼

6. Frontend:
   └─ Clear localStorage cart
   └─ Show success message
   └─ Redirect to /profile
```

---

## Data Flow Diagrams

### Cart → Order Flow:

```
LocalStorage (Cart)          API Server              Database
─────────────────           ───────────            ──────────

[Item 1]
  - id: 5
  - name: Guitar
  - price: 1299.99    ────────────▶  POST /api/orders ────▶ INSERT orders
  - qty: 1                                                  INSERT order_items
                                                            UPDATE products
[Item 2]                                                    UPDATE sales_tracking
  - id: 2
  - name: Piano
  - price: 649.99     ────────────▶  Create Order  ────▶  COMMIT
  - qty: 1
                      ◀────────────── Success ◀────────  Response
                                                         {order_id: 42}
Clear Cart
Redirect Profile
```

### Profile → Order Details Flow:

```
Profile Page         GET /api/user/orders      Database
─────────────       ─────────────────────      ────────

Load Orders    ─────────────────────────────▶  SELECT FROM orders
               ◀───────────────────────────── WHERE user_id = 5

[Order #42]
               ─────────────────────────────▶  SELECT FROM order_items
View Details   ◀───────────────────────────── WHERE order_id = 42

               JOIN with products table

Show Modal     ◀─────────────────────────────
with Details      Order info + Items + Images
```

---

## API Request/Response Examples

### Create Order Request:

```
POST /api/orders
Content-Type: application/json

{
  "items": [
    {
      "id": 5,
      "name": "Fender Stratocaster",
      "price": 1299.99,
      "quantity": 1
    },
    {
      "id": 2,
      "name": "Yamaha P-125 Piano",
      "price": 649.99,
      "quantity": 1
    }
  ],
  "payment_method": "cash_on_delivery",
  "delivery_address": "John Doe, 123 Main St, New York, NY 10001"
}

Response:
{
  "message": "Order created successfully",
  "order_id": 42,
  "status": "pending"
}
```

### Get User Orders Request:

```
GET /api/user/orders

Response:
[
  {
    "id": 42,
    "user_id": 5,
    "total_amount": 1949.98,
    "status": "pending",
    "payment_method": "cash_on_delivery",
    "delivery_address": "John Doe, ...",
    "created_at": "2024-12-29 14:30:00"
  },
  {
    "id": 41,
    "user_id": 5,
    "total_amount": 99.99,
    "status": "delivered",
    "payment_method": "credit_card",
    "delivery_address": "John Doe, ...",
    "created_at": "2024-12-28 10:15:00"
  }
]
```

### Sales Data Request:

```
GET /api/admin/sales-data

Response:
[
  {
    "id": 1,
    "product_id": 5,
    "name": "Fender Stratocaster",
    "category": "Guitars",
    "quantity_sold": 15,
    "total_revenue": 19499.85,
    "last_updated": "2024-12-29 14:30:00"
  },
  {
    "id": 2,
    "product_id": 2,
    "name": "Yamaha P-125 Piano",
    "category": "Pianos & Keyboards",
    "quantity_sold": 8,
    "total_revenue": 5199.92,
    "last_updated": "2024-12-29 14:25:00"
  }
]
```

---

## State Management

### Local Storage (Client):

```
Key: "musicStoreCart"
Value: [
  {
    id: 5,
    name: "Fender Stratocaster",
    price: 1299.99,
    image: "...",
    quantity: 1
  },
  {
    id: 2,
    name: "Yamaha P-125 Piano",
    price: 649.99,
    image: "...",
    quantity: 1
  }
]
```

### Session Storage (Server):

```
Flask Session:
{
  "user_id": 5,
  "username": "john_doe",
  "is_admin": false
}
```

---

## Component Interaction Map

```
                    INDEX.HTML
                        │
        ┌───────────────┼───────────────┐
        │               │               │
        ▼               ▼               ▼
    NAVBAR.JS      SHOP.JS         CART.JS
        │               │               │
        │               │      ┌────────┴────────┐
        │               │      │                 │
        │               ▼      ▼                 ▼
        │           CHECKOUT.HTML          PROFILE.HTML
        │               │                       │
        │               ▼                       ▼
        │           CHECKOUT.JS            PROFILE.JS
        │               │                       │
        │               └───────────┬───────────┘
        │                           │
        └───────────────┬───────────┘
                        │
                        ▼
                    API ENDPOINTS
                        │
        ┌───────────────┼───────────────┐
        │               │               │
        ▼               ▼               ▼
    AUTH API       ORDER API       ADMIN API
        │               │               │
        └───────────────┼───────────────┘
                        │
                        ▼
                    DATABASE
```

---

## Technology Stack Visualization

```
┌─────────────────────────────────────────┐
│          PRESENTATION LAYER             │
│  ├─ HTML5 (Templates)                  │
│  ├─ CSS3 (Responsive Design)           │
│  └─ JavaScript (Vanilla - ES6)         │
└─────────────────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────┐
│         BUSINESS LOGIC LAYER            │
│  ├─ Flask Web Framework                │
│  ├─ Route Handlers                     │
│  └─ API Endpoints                      │
└─────────────────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────┐
│         DATA ACCESS LAYER               │
│  ├─ SQLite Database                    │
│  ├─ SQL Queries                        │
│  └─ Data Models                        │
└─────────────────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────┐
│         STORAGE LAYER                   │
│  ├─ music_store.db (SQLite)            │
│  ├─ localStorage (Client-side)         │
│  └─ Session Data                       │
└─────────────────────────────────────────┘
```

---

## Deployment Architecture

```
┌──────────────────────────────────────────┐
│         CLIENT BROWSER                   │
│  ├─ HTML/CSS/JavaScript                 │
│  └─ localStorage Cache                  │
└──────────────────────────────────────────┘
              │ HTTP/S │
              ▼        ▲
┌──────────────────────────────────────────┐
│      WEB SERVER (Flask)                  │
│  ├─ app.py (Main Application)           │
│  ├─ Routes & Endpoints                  │
│  ├─ Session Management                  │
│  └─ Request Handlers                    │
└──────────────────────────────────────────┘
              │
              ▼
┌──────────────────────────────────────────┐
│    DATABASE (SQLite)                     │
│  ├─ users Table                         │
│  ├─ products Table                      │
│  ├─ orders Table                        │
│  ├─ order_items Table                   │
│  └─ sales_tracking Table                │
└──────────────────────────────────────────┘
```

---

**End of Architecture & Flow Guide**
